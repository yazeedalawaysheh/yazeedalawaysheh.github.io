# Yazeed Academic Website
Ready for GitHub Pages.
Upload contents to repository root and enable Pages.